<?php

$connection_string = "mysql:host=localhost; dbname=test_friendsfusion_db";
$user ="toussant348";
$password = "pinkpanther348"; 
$connection = null;

function connectionTester(){
    global $connection_string, $user, $password, $connection;
    try{
        $conn = new PDO($connection_string, $user, $password);
        $connection =$conn;
        //print($connection->exec("DROP DATABASE test_friendsfusion_db"));
    }catch(PDOException $err){
        return $err->getCode();
    }      
}

function createDatabaseStructure(){  
    global $user, $password, $connection;
    $sql= "CREATE DATABASE test_friendsfusion_db;";
    $sql_user_accounts = "CREATE TABLE USER_ACCOUNTS(
                            user_username VARCHAR(20) NOT NULL,
                            user_password VARCHAR(15) NOT NULL,
                            user_first_name VARCHAR(20) NOT NULL,
                            user_last_name VARCHAR(20) NOT NULL,
                            user_email VARCHAR(20) NOT NULL,
                            user_dob_d INT NOT NULL,
                            user_dob_m INT NOT NULL,
                            user_dob_y INT NOT NULL,
                            PRIMARY KEY(user_username));";
    $sql_blogs = "CREATE TABLE BLOGS(
                            blog_id VARCHAR(200) NOT NULL,
                            blog_caption VARCHAR(200) NOT NULL,
                            blog_pic_location VARCHAR(200),
                            PRIMARY KEY(blog_id));";
    $sql_blog_comments = "CREATE TABLE BLOG_COMMENTS(
                            comment_blog_id VARCHAR(200) NOT NULL,
                            comment_text VARCHAR(200) NOT NULL,
                            comment_user_who_posted VARCHAR(200),
                            PRIMARY KEY(comment_blog_id));";
    $sql_pictures = "CREATE TABLE PICTURES(
                        pictures_id VARCHAR(200) NOT NULL,
                        picture_location VARCHAR(500) NOT NULL,
                        PRIMARY KEY(pictures_id));";
    $connection_string = "mysql:host=localhost;";
    //Just Connect to the database without linking it to a database
    try{
        $connection = new PDO($connection_string, $user, $password);
        $connection->exec($sql);
        //Test Back the connection for the database
        connectionTester();
    }catch(PDOException $err){
        include('C:\xampp\htdocs\FriendsFusion\Data\html\fail_database_connection.html');
        die("Fatal Error while attempting Fix");
    }
    $connection->exec($sql_user_accounts);
    $connection->exec($sql_blogs);
    $connection->exec($sql_blog_comments);
    //print(var_dump($connection->errorInfo()));
    $connection->exec($sql_pictures);
}

$errorCode = connectionTester();
// Apply the neccesary Fix to the connection
if($errorCode == 2002){
    include('C:\xampp\htdocs\FriendsFusion\Data\html\fail_database_connection.html');
    die();
} else if($errorCode == 1049){
    createDatabaseStructure();
}

$connection = null; 
?>